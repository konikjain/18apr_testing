Action()
{

/*Correlation comment - Do not change!  Original value='136926.042203321HAtDVDDpcQfiDDDDtccfipHQQHHf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=userSession",
		"RegExp=name=\"userSession\"\\ value=\"(.*?)\"/>\\\n<table\\ border",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("welcome.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/index.htm", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://pki.goog/repo/certs/gts1c3.der", "Referer=", ENDITEM, 
		"Url=http://pki.goog/repo/certs/gtsr1.der", "Referer=", ENDITEM, 
		LAST);

	lr_save_string(lr_decrypt("64c0b9e18a47b02f"), "PasswordParameter");

	web_submit_data("login.pl",
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t2.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value={PasswordParameter}", ENDITEM,
		"Name=login.x", "Value=49", ENDITEM,
		"Name=login.y", "Value=9", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		EXTRARES,
		"URL=http://pki.goog/repo/certs/gts1c3.der", ENDITEM,
		"URL=http://pki.goog/repo/certs/gtsr1.der", ENDITEM,
		LAST);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:9-eGhbicurGLCJq9z29Qxt8wiTSwB-rZJPfRxbPjvwI&cup2hreq=9e0375e112d4f781d924c0cf671595aef761fed7f3a3463e1201ed7df8eefc12", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"cohorthint\":\"Win (Including up-to-date)\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.aeedb246d19256a956fedaa89fb62423ae5bd8855a2a1f3189161cf045645a19\"}]},\"ping\":{\"ping_freshness\":\"{e75d6b65-d96a-4e4b-b210-1a7b2158959b}\",\"rd\":6049},\"updatecheck\":{},\"version\":\""
		"1.3.36.141\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohorthint\":\"Windows (102+, canary/dev/beta/stable)\",\"cohortname\":\"Windows (102+, canary/dev/beta/stable)\",\"enabled\":true,\"installdate\":5825,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.faef821457e35b44f92e45ae9c7c4424eb39c8f8bd02562a358bd2c5542570b9\"}]},\"ping\":{\"ping_freshness\":\"{874f4ca7-2223-49df-8855-715349b8e61a}\",\"rd\":6049},\"updatecheck\":{},\"version\""
		":\"1.0.2512.0\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{11d5bfea-7ddb-4f4a-aabf-e30a88158fcd}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1n4r:\",\"cohorthint\":\"4.10.2557.0 for Chrome 95+\",\"cohortname\":\"Chrome 113+\",\""
		"enabled\":true,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{e363a77b-e717-43e6-8393-899958b8d6a8}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"4.10.2662.3\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.edcd896daca682660c257dfe2314ad2b56f4705f6b651cb3331a16b84a4d4461\"}]},\"ping\":{\""
		"ping_freshness\":\"{93fa1737-79e0-497c-974c-2a7d5f741d73}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"20230713.548486833.14\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.4d4a9ece68f12d31fb4ebe458e7cbbce6bd27a5d363bce3344b1f4b5c6b024b4\"}]},\"ping\":{\"ping_freshness\":\"{55cc1ec1-730f-41ed-98fe-f204ceb1c5aa}\",\"rd\":6049},\""
		"tag\":\"default\",\"updatecheck\":{},\"version\":\"58\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{4daddb04-4bbc-4ec1-b943-fe81dace3e3b}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\""
		"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.bd94db56207a4e718b8b7a76146141dc5aa2ce3528950cde76ebacd9b4811282\"}]},\"ping\":{\"ping_freshness\":\"{73e29420-7eb5-46c4-b03f-9a9bba651d28}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"2981\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:\",\"cohorthint"
		"\":\"108-and-above-all-users\",\"cohortname\":\"108-and-above-all-users\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.ed2f4d0fa9d2f99837719f80e3990498314290c6a294a72296ddcada784dd278\"}]},\"ping\":{\"ping_freshness\":\"{9baa020a-9230-4a6c-871d-1eed8d73c21e}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"2022.12.16.779\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"All users\",\""
		"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{d9193187-190d-46c5-9974-c0826c0dc895}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.e29e642db998c8147d0a35c42b80be2cb85e013bb1288a80d3ceaba0289bccd8\"}]},\"ping\":{\"ping_freshness\":\"{d84ce685-f1fd-4c53-817d-d27080d3d8ec}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"402\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GGLS\",\"cohort\":\"1:1iaf:\",\"cohorthint\":\"desktop_1_flatbuffer\",\"cohortname\":\"windows_flatbuffers\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.3525bd7c472e4c85cadf1b8d0992ca8303b9e630831e4530e54a14a70f213a11\"}]},\"ping\":{\"ping_freshness\":\"{b81c10fd-7c81-49b0-af7e-42d75e94017c}\",\"rd\":6049},\"tag\":\"desktop_1_flatbuffer\",\"updatecheck\":{},\"version\":\"30.2\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.ab8d70a60ce0fba1355fad4edab88fd4d1bccc566b230998180183d1d776992b\"}]},\"ping\":{\"ping_freshness\":\""
		"{33b66373-939b-4333-8c14-cab1f79d9ae2}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"1.0.0.13\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohorthint\":\"Auto Stage3\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.b908b3b6637f257224b58396a6c37d0f18df42bda937306f3e64b2982e8ec8eb\"}]},\"ping\":{\"ping_freshness\":\"{9006fdda-c58c-4d25-b34d-77a37a6a6b63}\",\"rd\":6049},\"updatecheck\":{},\""
		"version\":\"655\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54AndUp\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.4c67e9ab7c30c48322e5f6fe5acbd64132c054ebb91bd510b414b1506167ffc9\"}]},\"ping\":{\"ping_freshness\":\"{9f9cd05d-1a27-4aa0-9b84-b81b76135bf1}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"9.47.0\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS"
		"\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{1c97e731-65bf-4089-ba86-eb04e2a217da}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\""
		"package\":[{\"fp\":\"1.1cd7dc2056afaa0f6a705c9a17d22bba6578b33f5dae9e2d6518a0bfcced2396\"}]},\"ping\":{\"ping_freshness\":\"{3b3e60b8-9601-4dc3-821c-327c2e084a4f}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{75be0224-15c8-4277-a697-20a58da5a65e}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.5d7fd5c353ee38518a13f104cb1907af768633787e4ab02aec29a84bb97a509f\"}]},\"ping\":"
		"{\"ping_freshness\":\"{270097dc-90e1-4290-95c6-f82085a54f52}\",\"rd\":6049},\"updatecheck\":{},\"version\":\"8136\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.d21ca36f654c82850d0a594f3062f45ccc214e8c51399ab27c77cebb5b86451e\"}]},\"ping\":{\"ping_freshness\":\"{dec0c950-57fc-4f63-8389-e3b0793e4d35}\",\"rd\":6049},\"updatecheck\":{}"
		",\"version\":\"117.0.5910.0\"},{\"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohorthint\":\"General release\",\"cohortname\":\"Auto General release\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.cd2aee6eaa7d46fca6810cd71eae20ffb4bd1f4a3dd0e7b9b64a63c500177e05\"}]},\"ping\":{\"ping_freshness\":\"{46cc9448-803f-4abe-bbdb-a8151aaaeb43}\",\"rd\":6049},\"updatecheck\":{},\"version\":\""
		"2023.6.30.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":4,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3208\"},\"prodversion\":\"115.0.5790.110\",\"protocol\":\"3.1\",\"requestid\":\"{5033e032-145e-43f5-a756-d9b24fc01485}\",\"sessionid\":\"{46643a97-8a8b-49b3-acff-c198eacd91f2}\",\""
		"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.272\"},\"updaterversion\":\"115.0.5790.110\"}}", 
		LAST);

	web_url("welcome.pl_2", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=search", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Snapshot=t5.inf", 
		LAST);

	web_image("Home Button", 
		"Alt=Home Button", 
		"Ordinal=1", 
		"Snapshot=t6.inf", 
		LAST);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Ordinal=1", 
		"Snapshot=t7.inf", 
		LAST);

	return 0;
}